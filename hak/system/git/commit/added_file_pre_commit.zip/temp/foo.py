run = lambda: None
test = lambda: False
